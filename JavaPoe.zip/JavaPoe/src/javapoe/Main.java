package javapoe;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        javapoe acc = new javapoe();
        
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String cell = JOptionPane.showInputDialog("Enter cell number(+27.........:");
        
        String reg = acc.registerUser(username, password, cell);
        
        JOptionPane.showMessageDialog(null, reg);
        
        if (!
                reg.toLowerCase().contains("successfully")) {
            return;
        }
        String lu = JOptionPane.showInputDialog("LOGIN Enter username:");
        String Ip = JOptionPane.showInputDialog("LOGIN Enter password:");
        
        String status = acc.returnLoginStatus(lu, Ip);
        
        JOptionPane.showMessageDialog(null, status);
    }
    
}